import { Component } from '@angular/core';

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Firebase } from '@ionic-native/firebase/ngx';
import { FirebaseConfig } from '@ionic-native/firebase-config/ngx';

const config ={
  apiKey: "AIzaSyDG519drFkpew3JcCQWfKUQkO7HiA7bLnU",
  authDomain: "granthamproject-e7894.firebaseapp.com",
  databaseURL: "https://granthamproject-e7894.firebaseio.com",
  projectId: "granthamproject-e7894",
  storageBucket: "granthamproject-e7894.appspot.com",
  messagingSenderId: "1068255153349",
  appId: "1:1068255153349:web:4a39d374465b23f2"
}

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar
  ) {
    this.initializeApp();
  }

  initializeApp() {
  this.platform.ready().then(() => {
    this.statusBar.styleDefault();
    this.splashScreen.hide();
  });
  }}